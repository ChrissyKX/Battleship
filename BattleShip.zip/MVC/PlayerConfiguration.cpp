//
// Created by mfbut on 3/9/2019.
//

#include "PlayerConfiguration.h"

BattleShip::PlayerConfiguration::PlayerConfiguration(int numHumanPlayers, int numAiPlayers) : numHumanPlayers(
    numHumanPlayers), numAiPlayers(numAiPlayers) {}
